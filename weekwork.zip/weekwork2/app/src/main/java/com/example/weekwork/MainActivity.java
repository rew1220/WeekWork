package com.example.weekwork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.format.ArrayWeekDayFormatter;
import com.prolificinteractive.materialcalendarview.format.MonthArrayTitleFormatter;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.time.temporal.WeekFields;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    String[] subject = new String[5];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialCalendarView calendarView = findViewById(R.id.MCV);
        TextView[] sbj = new TextView[5];
        sbj[0] = findViewById(R.id.TV_sbj1);
        sbj[1] = findViewById(R.id.TV_sbj2);
        sbj[2] = findViewById(R.id.TV_sbj3);
        sbj[3] = findViewById(R.id.TV_sbj4);
        sbj[4] = findViewById(R.id.TV_sbj5);

        Button[] delbtn = new Button[5];
        delbtn[0] = findViewById(R.id.Btn_sbj1);
        delbtn[1] = findViewById(R.id.Btn_sbj2);
        delbtn[2] = findViewById(R.id.Btn_sbj3);
        delbtn[3] = findViewById(R.id.Btn_sbj4);
        delbtn[4] = findViewById(R.id.Btn_sbj5);

        CheckBox[] chk = new CheckBox[5];
        chk[0] = findViewById(R.id.Chk_sbj1);
        chk[1] = findViewById(R.id.Chk_sbj2);
        chk[2] = findViewById(R.id.Chk_sbj3);
        chk[3] = findViewById(R.id.Chk_sbj4);
        chk[4] = findViewById(R.id.Chk_sbj5);

        TextView tvcomplete = findViewById(R.id.TV_complete);
        tvcomplete.setAlpha(0);


        EditText todo = findViewById(R.id.ET_todo);

        calendarView.setTitleFormatter(new MonthArrayTitleFormatter(getResources().getTextArray(R.array.custom_months)));
        calendarView.setWeekDayFormatter(new ArrayWeekDayFormatter(getResources().getTextArray(R.array.custom_weekdays)));


        Button btn_submit = findViewById(R.id.btn_submit);
        int i = 0;

        //목표 불러오기
        readfunc(sbj);

        //주 확인
        checkweek(chk);


        for(i = 0; i < 5; i++){
            int finalI = i;
            //삭제버튼
            delbtn[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(subject[finalI]!=null) {
                        sbj[finalI].setText(null);
                        subject[finalI] = null;
                        writefunc("__PASSTHISWORD__");
                        readfunc(sbj);
                        deleted(chk, finalI);
                        checkchk(chk,tvcomplete);
                    }
                }
            });
            //체크버튼
            chk[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    checkchk(chk, tvcomplete);
                }
            });
        }

        //목표 확인 버튼
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writefunc(todo.getText().toString());
                readfunc(sbj);
                todo.setText("");
            }
        });



    }

    //-------------------[함수]----------------------

    //파일 읽기 함수
    void readfunc(TextView[] sbj){
        //초기화
        for(int i = 0; i < 5; i++){
            sbj[i].setText(null);
            subject[i] = null;
        }
        int i = 0;
        File WWfile = new File(MainActivity.super.getExternalFilesDir("WeekWork").getAbsolutePath()+"/WWfile.txt");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(WWfile));
            String line;
            while((line = reader.readLine()) != null){
                subject[i] = line;
                Log.i("finder",subject[i]);
                sbj[i].setText(line);
                i++;
            }
            reader.close();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    //파일 쓰기 함수

    void writefunc(String todo){
        FileWriter writer;
        int count = 0;

        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < 5; i++){
            if(subject[i] == null)continue;
            stringBuilder.append(subject[i]+"\n");
            count++;
        }
        if(todo != "__PASSTHISWORD__") stringBuilder.append(todo+"\n");

        try {
            if(todo.length()==0)throw new Exception("값이 존재하지 않습니다!");
            if(count == 5)throw new Exception("목표칸이 다 찼습니다!");

            String FPath = MainActivity.super.getExternalFilesDir("WeekWork").getAbsolutePath();
            Log.i("finder",FPath);

            File WWdir = new File(FPath);
            if (!WWdir.exists()) {
                WWdir.mkdir();
                Log.i("finder","check1");
            }

            File WWfile = new File(WWdir + "/WWfile.txt");
            if (!WWfile.exists()) {
                WWfile.createNewFile();
                Log.i("finder","check2");
            }

            writer = new FileWriter(WWfile, false);
            writer.write(stringBuilder.toString());
            writer.flush();
            writer.close();

        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
    void deleted(CheckBox[] chk, int start){
        for(int i = start; i < 4; i++){
            if(chk[i+1].isChecked()){
                chk[i].setChecked(true);
                chk[i+1].setChecked(false);
            }else chk[i].setChecked(false);
        }
        chk[4].setChecked(false);
    }
    void checkchk(CheckBox[] chk, TextView tv_complete){
        int complen = 0, compcou = 0;
        for (int i = 0; i < 5; i++){
            if(subject[i]==null)continue;
            if(chk[i].isChecked())compcou++;
            complen++;
        }
        if(compcou == complen && complen > 0) tv_complete.setAlpha(1);
        else tv_complete.setAlpha(0);
    }

    void checkweek(CheckBox[] chk){

        Calendar c = Calendar.getInstance();
        String week = String.valueOf(c.get(Calendar.WEEK_OF_YEAR));
        Log.i("Wfinder",week);

        try {
            File WWweekfile = new File(MainActivity.this.getExternalFilesDir("WeekWork").getAbsolutePath()+"/WWweekfile.txt");
            if (!WWweekfile.exists()) {
                WWweekfile.createNewFile();
            }
            BufferedReader reader = new BufferedReader(new FileReader(WWweekfile));
            String line;

            Log.i("finder","checked!");

            line = reader.readLine();


            if(week != line){
                for(int i = 0; i < 5; i++){
                    chk[i].setChecked(false);
                }
                FileWriter writer;
                writer = new FileWriter(WWweekfile, false);
                writer.write(week);
                writer.flush();
                writer.close();
            }

            reader.close();
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_SHORT);
        }
    }
}